// Isi konfigurasi ini dari Firebase Console > Project settings > Your apps.
// Jangan bagikan file konfigurasi beserta kredensial atau data pengguna secara publik.
export const firebaseConfig = {
  apiKey: "AIzaSyAelFgGYv1TnkIGd28XsdyCxYyUlqYTfic",
 authDomain "nata-planner.firebaseapp.com",
  projectId: "nata-planner",
  storageBucket: "nata-planner.firebasestorage.app",
  messagingSenderId: "329461068598",
  appId: "1:329461068598:web:3f57f9942522a14dc53997",
};
export const firebaseConfigured = !Object.values(firebaseConfig).some(v => String(v).startsWith("ISI_"));