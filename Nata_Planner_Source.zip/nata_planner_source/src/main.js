import './style.css';
import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider, signInWithPopup, signOut, onAuthStateChanged } from 'firebase/auth';
import { getFirestore, collection, doc, setDoc, deleteDoc, onSnapshot, query, orderBy } from 'firebase/firestore';
import { firebaseConfig, firebaseConfigured } from './firebase-config.js';

const $ = id => document.getElementById(id);
const todayISO = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`; };
const parseDate = s => new Date(`${s}T12:00:00`);
const formatDate = s => parseDate(s).toLocaleDateString('id-ID',{weekday:'long',day:'numeric',month:'long',year:'numeric'});
const esc = s => String(s ?? '').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
let auth, db, currentUser=null, events=[], tasks=[], selected=todayISO(), view='day', unsubEvents=null, unsubTasks=null, notified=new Set();

if (firebaseConfigured) {
  const app = initializeApp(firebaseConfig);
  auth = getAuth(app); db = getFirestore(app);
} else {
  $('setupMessage').textContent = 'Setup diperlukan: isi konfigurasi Firebase di src/firebase-config.js sebelum login dapat digunakan.';
  $('loginBtn').disabled = true;
  $('loginBtn').textContent = 'Selesaikan setup Firebase terlebih dahulu';
}
$('loginBtn').onclick = async () => {
  try { await signInWithPopup(auth,new GoogleAuthProvider()); }
  catch(e) { alert('Login gagal: '+e.message); }
};
$('logoutBtn').onclick = () => signOut(auth);
if (auth) onAuthStateChanged(auth, user => {
  currentUser=user;
  $('authPanel').hidden=!!user; $('planner').hidden=!user;
  if (!user) { if(unsubEvents)unsubEvents();if(unsubTasks)unsubTasks();events=[];tasks=[];return; }
  $('userName').textContent=user.displayName || user.email || 'Planner';
  $('syncState').textContent='Menghubungkan…';
  const evRef=collection(db,'users',user.uid,'events'), taskRef=collection(db,'users',user.uid,'tasks');
  unsubEvents=onSnapshot(query(evRef,orderBy('date')),snap=>{events=snap.docs.map(d=>({id:d.id,...d.data()}));$('syncState').textContent='Tersinkronisasi';render();},err=>{$('syncState').textContent='Sinkronisasi gagal';console.error(err)});
  unsubTasks=onSnapshot(taskRef,snap=>{tasks=snap.docs.map(d=>({id:d.id,...d.data()}));renderTasks();},err=>console.error(err));
});

function mondayOf(s){const d=parseDate(s);const n=d.getDay();d.setDate(d.getDate()+(n===0?-6:1-n));return d}
function dateISO(d){return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function renderWeekStrip(){
  const mon=mondayOf(selected);$('weekStrip').innerHTML='';
  for(let i=0;i<7;i++){const d=new Date(mon);d.setDate(mon.getDate()+i);const s=dateISO(d);const b=document.createElement('button');b.className='weekday'+(s===selected?' chosen':'')+(events.some(e=>e.date===s)?' has-events':'');b.innerHTML=`<small>${d.toLocaleDateString('id-ID',{weekday:'short'})}</small><strong>${d.getDate()}</strong>`;b.onclick=()=>{selected=s;render()};$('weekStrip').append(b)}
}
function eventCard(e){
 const el=document.createElement('article');el.className='event '+(e.done?'is-done':'');
 el.innerHTML=`<div class="eventtime">${esc(e.time||'--:--')}</div><div class="eventmain"><strong>${esc(e.title)}</strong><div class="eventmeta"><span class="tag ${e.category==='Pekerjaan'?'work':''}">${esc(e.category||'Pribadi')}</span>${e.notes?`<span>${esc(e.notes)}</span>`:''}${Number(e.reminder)>0?`<span>Pengingat ${e.reminder} mnt</span>`:''}</div></div><div class="eventactions"><button data-action="done" title="Tandai selesai">✓</button><button data-action="edit" title="Edit">✎</button><button data-action="delete" title="Hapus">×</button></div>`;
 el.querySelector('[data-action=done]').onclick=()=>updateEvent({...e,done:!e.done});
 el.querySelector('[data-action=edit]').onclick=()=>fillEvent(e);
 el.querySelector('[data-action=delete]').onclick=async()=>{if(confirm('Hapus jadwal ini?'))await deleteDoc(doc(db,'users',currentUser.uid,'events',e.id))};
 return el;
}
function render(){
 $('dateTitle').textContent=formatDate(selected);$('dateSubtitle').textContent=events.filter(e=>e.date===selected).length+' aktivitas';$('eventDate').value=selected;
 renderWeekStrip();
 const list=$('agendaList');list.innerHTML='';
 const dayEvents=events.filter(e=>e.date===selected).sort((a,b)=>(a.time||'').localeCompare(b.time||''));
 if(!dayEvents.length)list.innerHTML='<div class="empty">Belum ada jadwal pada tanggal ini.<br>Tambahkan aktivitas melalui formulir.</div>';
 dayEvents.forEach(e=>list.append(eventCard(e)));
 $('agendaList').hidden=view!=='day';$('weekView').hidden=view!=='week';
 if(view==='week'){
  const mon=mondayOf(selected);$('weekView').innerHTML='';
  for(let i=0;i<7;i++){const d=new Date(mon);d.setDate(mon.getDate()+i);const s=dateISO(d);const group=events.filter(e=>e.date===s).sort((a,b)=>(a.time||'').localeCompare(b.time||''));const sec=document.createElement('div');sec.className='weekdaygroup';sec.innerHTML=`<h3>${esc(d.toLocaleDateString('id-ID',{weekday:'long',day:'numeric',month:'short'}))}</h3>`;if(group.length)group.forEach(e=>sec.append(eventCard(e)));else sec.insertAdjacentHTML('beforeend','<p class="muted small">Tidak ada aktivitas</p>');$('weekView').append(sec)}
 }
 renderTasks();
}
async function updateEvent(e){const {id,...data}=e;await setDoc(doc(db,'users',currentUser.uid,'events',id),data)}
$('eventForm').onsubmit=async ev=>{
 ev.preventDefault();if(!currentUser)return;
 const id=$('eventId').value||crypto.randomUUID();
 const data={title:$('eventTitle').value.trim(),date:$('eventDate').value,time:$('eventTime').value,category:$('eventCategory').value,reminder:Number($('eventReminder').value),notes:$('eventNotes').value.trim(),done:events.find(e=>e.id===id)?.done||false,updatedAt:Date.now()};
 if(!data.title)return;
 await setDoc(doc(db,'users',currentUser.uid,'events',id),data);selected=data.date;resetEventForm();render();
};
function fillEvent(e){$('eventId').value=e.id;$('eventTitle').value=e.title;$('eventDate').value=e.date;$('eventTime').value=e.time;$('eventCategory').value=e.category||'Pribadi';$('eventReminder').value=String(e.reminder||0);$('eventNotes').value=e.notes||'';$('eventFormTitle').textContent='Edit jadwal';$('cancelEdit').hidden=false;$('eventFormTitle').scrollIntoView({behavior:'smooth',block:'center'})}
function resetEventForm(){$('eventForm').reset();$('eventId').value='';$('eventDate').value=selected;$('eventFormTitle').textContent='Tambah jadwal';$('cancelEdit').hidden=true}
$('cancelEdit').onclick=resetEventForm;
$('taskForm').onsubmit=async e=>{e.preventDefault();const title=$('taskTitle').value.trim();if(!title||!currentUser)return;const id=crypto.randomUUID();await setDoc(doc(db,'users',currentUser.uid,'tasks',id),{title,date:selected,done:false,createdAt:Date.now()});$('taskTitle').value='';};
function renderTasks(){if(!$('taskList'))return;const list=$('taskList');list.innerHTML='';const day=tasks.filter(t=>t.date===selected).sort((a,b)=>(a.createdAt||0)-(b.createdAt||0));if(!day.length)list.innerHTML='<div class="empty">Belum ada tugas untuk tanggal ini.</div>';day.forEach(t=>{const row=document.createElement('div');row.className='taskrow';row.innerHTML=`<input type="checkbox" ${t.done?'checked':''} aria-label="Selesai"><div class="tasktitle ${t.done?'is-done':''}">${esc(t.title)}</div><button class="delete-task" aria-label="Hapus">×</button>`;row.querySelector('input').onchange=()=>setDoc(doc(db,'users',currentUser.uid,'tasks',t.id),{...t,done:!t.done});row.querySelector('button').onclick=()=>deleteDoc(doc(db,'users',currentUser.uid,'tasks',t.id));list.append(row)})}
$('prevDay').onclick=()=>{const d=parseDate(selected);d.setDate(d.getDate()-1);selected=dateISO(d);render()};
$('nextDay').onclick=()=>{const d=parseDate(selected);d.setDate(d.getDate()+1);selected=dateISO(d);render()};
$('todayBtn').onclick=()=>{selected=todayISO();render()};
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{view=b.dataset.view;document.querySelectorAll('.tab').forEach(x=>x.classList.toggle('active',x===b));render()});
async function backup(download=true){
 const payload={app:'Nata Planner',version:1,createdAt:new Date().toISOString(),events,tasks};
 if(download){const blob=new Blob([JSON.stringify(payload,null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`nata-planner-backup-${todayISO()}.json`;a.click();URL.revokeObjectURL(a.href)}
 return payload;
}
$('backupBtn').onclick=()=>backup(true);$('exportBtn').onclick=()=>backup(true);
$('importFile').onchange=async ev=>{const file=ev.target.files[0];if(!file||!currentUser)return;try{const data=JSON.parse(await file.text());if(!Array.isArray(data.events)||!Array.isArray(data.tasks))throw new Error('Format backup tidak dikenali');if(!confirm('Pulihkan backup dengan menambahkan data ke akun ini? Data lama tidak dihapus.'))return;for(const e of data.events){const id=crypto.randomUUID();const {id:oldId,...rest}=e;await setDoc(doc(db,'users',currentUser.uid,'events',id),rest)}for(const t of data.tasks){const id=crypto.randomUUID();const {id:oldId,...rest}=t;await setDoc(doc(db,'users',currentUser.uid,'tasks',id),rest)}alert('Backup berhasil ditambahkan ke cloud.')}catch(err){alert('Tidak dapat memulihkan backup: '+err.message)}finally{ev.target.value=''}};
if('serviceWorker'in navigator && location.protocol!=='file:')navigator.serviceWorker.register('/sw.js').catch(console.warn);
if('Notification'in window && Notification.permission==='granted'){
 setInterval(()=>{const now=new Date();events.forEach(e=>{if(!e.reminder||e.done)return;const at=new Date(`${e.date}T${e.time}:00`);at.setMinutes(at.getMinutes()-Number(e.reminder));const key=e.id+'_'+at.getTime();if(now>=at&&now<new Date(at.getTime()+60000)&&!notified.has(key)){notified.add(key);new Notification('Nata Planner: '+e.title,{body:`Mulai pukul ${e.time}${e.notes?' · '+e.notes:''}`})}})},20000)
}
if(window.Capacitor?.isNativePlatform?.()){
 import('@capacitor/local-notifications').then(({LocalNotifications})=>{
  $('setupMessage').textContent='Mode aplikasi Android terdeteksi.';
  $('notifyBtn')?.addEventListener('click',async()=>{await LocalNotifications.requestPermissions()});
 }).catch(()=>{});
}
