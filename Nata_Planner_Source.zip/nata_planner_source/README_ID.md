# Nata Planner — paket sumber awal

Paket ini berisi aplikasi web responsif/PWA dan konfigurasi untuk membungkusnya menjadi APK Android menggunakan Capacitor. Sinkronisasi lintas perangkat menggunakan Firebase Authentication (Google) dan Cloud Firestore.

## Yang sudah ada di source
- Login Google melalui Firebase Authentication.
- Data jadwal dan tugas terpisah per akun pengguna di Firestore.
- Agenda harian, strip kalender mingguan, ringkasan minggu.
- Tambah/edit/hapus jadwal, kategori pribadi/pekerjaan, penanda selesai.
- Tugas per tanggal dan status selesai.
- Ekspor JSON dan impor/pemulihan data (menambahkan data backup, tidak menghapus data lama).
- Manifest PWA, ikon, service worker untuk shell offline.
- File konfigurasi Capacitor untuk membangun APK Android.

## Yang belum aktif sebelum konfigurasi/deployment
Firebase project, login Google, Firestore, notifikasi, dan sinkronisasi **belum bisa dipakai** sampai kamu membuat project Firebase dan mengisi `src/firebase-config.js`, lalu mengaktifkan layanan dan melakukan deployment. Tidak ada server atau akun cloud yang dibuat otomatis dari paket ini.

## A. Siapkan Firebase gratis
1. Buka https://console.firebase.google.com/ dan buat project (misalnya `nata-planner-anda`).
2. Tambahkan aplikasi Web di Project settings, lalu salin konfigurasi Firebase ke `src/firebase-config.js`.
3. Authentication → Sign-in method → aktifkan Google.
4. Firestore Database → Create database. Untuk deployment publik, pasang aturan dari `firestore.rules`.
5. Authentication → Settings → Authorized domains: tambahkan domain hosting yang kamu gunakan.
6. Untuk production, tinjau aturan dan billing/kuota Firebase. Paket Spark gratis memiliki batas pemakaian dan kebijakan yang dapat berubah.

## B. Jalankan dashboard web secara lokal
Perlu Node.js LTS terpasang.
```bash
npm install
npm run dev
```
Buka alamat lokal yang ditampilkan Vite. Google login tidak akan bekerja sampai konfigurasi Firebase lengkap dan domain lokal diizinkan (biasanya `localhost`).

## C. Deploy dashboard ke Firebase Hosting
Pasang Firebase CLI, lalu login:
```bash
npm install -g firebase-tools
firebase login
npm run build
firebase init hosting
```
Pilih project Firebase yang sama, gunakan `dist` sebagai public directory, dan konfigurasi sebagai single-page app. File `firebase.json` sudah disediakan. Lalu:
```bash
firebase deploy --only hosting
```
Gunakan URL hosting yang keluar saat deploy untuk membuka dashboard di MacBook dan HP. Tambahkan domain hosting ke Authorized domains di Firebase Authentication.

## D. Bangun APK Android
Perlu Node.js LTS, Android Studio, Android SDK, dan JDK yang kompatibel dengan Android Studio.
```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```
Di Android Studio, tunggu Gradle selesai, lalu jalankan di perangkat untuk pengujian. Untuk APK debug, gunakan Build → Build Bundle(s) / APK(s) → Build APK(s). Untuk distribusi publik, siapkan signing key dan build release/AAB sesuai persyaratan Play Store.
`android/` dibuat oleh perintah `npx cap add android`, bukan disertakan sebagai folder hasil build di ZIP ini.

## E. Notifikasi — batasan penting
- Versi dashboard web meminta izin browser dan bisa menampilkan notifikasi pengingat saat halaman terbuka.
- Pengingat web tidak dijamin berjalan saat browser ditutup atau sistem membatasi aktivitas latar belakang.
- Untuk notifikasi Android yang andal saat aplikasi ditutup, perlu implementasi penjadwalan `@capacitor/local-notifications` pada native Android, termasuk izin Android 13+ dan pengujian perangkat. Source awal ini mencantumkan dependensi Capacitor, tetapi penjadwalan native belum dihubungkan penuh.
- Sinkronisasi cloud bekerja ketika perangkat online. Untuk jadwal yang dibuat offline, mekanisme antrean offline dan resolusi konflik lanjutan belum diimplementasikan.

## Privasi dan backup
Aturan Firestore membatasi akses data ke UID akun yang login. Jangan mempublikasikan kredensial server (service account). File backup JSON berisi jadwal dan catatan pribadi; simpan di lokasi aman. Firebase web config bukan password, tetapi aturan database tetap wajib benar.

## Isi folder
- `src/main.js` — UI, CRUD, sinkronisasi, backup.
- `src/firebase-config.js` — tempat konfigurasi Firebase.
- `src/style.css` — desain responsif.
- `public/` — ikon, manifest, service worker.
- `firestore.rules` — aturan keamanan awal.
- `capacitor.config.json` — identitas aplikasi Android.
